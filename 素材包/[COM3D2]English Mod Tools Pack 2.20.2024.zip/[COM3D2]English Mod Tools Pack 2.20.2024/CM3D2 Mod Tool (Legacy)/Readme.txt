This application is exclusively for the old .mod format that is now considered deprecated and causing performance issues. Only use it for editing, don't go making new stuff with it.

#CM3D2 Mod Editor
by usagirei @ HongFire

Custom Maid 3D 2 Mod Editor

---
###Features
* Compiled/Source Mod Opening
* Compiled/Source Mod Exporting
* Realtime 3D Preview[1][2]
* Icon Generation [3]
* Base Item Browsing [4]
* UV Map Generation [4]
* Texture Importing from game files [4]
* Drag and Drop Textures into your Image editor of choice (Reload on changes)

[1] Shader parameter changes allowed on Color/Float/Texture values. Requires a OpenGL 3.0 Enabled Graphics Card
[2] Materials are applied from the current editing mod, otherwise from the default model materials.
[3] Requires a Preview Window to be open.
[4] Requires game .arc files to be present

---
###FAQ
* My textures get resampled to 1024px when imported

Edit **config.ini** and change the **MaxTextureSize** property

* My arc files aren't in the GameData directory

Edit **config.ini** and change the **ArcDataPath** property

---
###Changelog

* 1.0.0.3 - Initial Public Release
* 1.0.0.4 - Fixed Casing Bug
* 1.0.0.5 - Enabled Texture Streaming
* 1.0.0.6 - Fixed Color Picker and Added Dynamic Window Coloring

