You may be wondering where the CM3d2 converter went, you should be using Luvoid's fork of the original with proper translations and even updates:
https://github.com/luvoid/Blender-CM3D2-Converter

The included modding guide was outdated and was removed.
The context menu tool was removed.
Many old and useless tools were scraped. The essentials are kept maintained.

For more resources, please join us in the CustomMaidServer: https://discord.me/custommaid 
or use link: https://discord.gg/cQX69rJ