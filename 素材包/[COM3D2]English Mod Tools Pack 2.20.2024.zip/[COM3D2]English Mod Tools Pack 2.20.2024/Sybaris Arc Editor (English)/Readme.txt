This is the best application for anything having to do with arc files by far.
A very simple and handy graphical interface makes locating the files you want to extract/replace etc very easy and now this app is 99% in english.

***To make use of it simply drop it in your install directory (your CM3d2 OR COM3D2 folder) or wherever your main CM3D2/COM3d2 application is located. Then just run it and you are good to go.
Sybaris Arc editor is completely stand alone and does not need sybaris to work and can work with reipatcher.

This app will open every arc file it can find in one window so you can easily use the search function to search through every arc instantly.
It can even help you find specific mods as it allows you to view loaded mods too by menu icon and category all in the menu tab. and it has many more features and tools.

NOTE: The app can take some time to show on screen after it has been opened because opening every single arc in the game isn't exactly easy.
But the wait is minimal and worth it compared to the benefits.

NOTE 2: With this newer version of SAE the load times are cut down by a lot and at most you will have a short wait time while switching tabs.

I take no credit for creating this application. I only take credit for translating and extend credit to Exkirion on hongfire for also translating.

Don't abuse your miedos!